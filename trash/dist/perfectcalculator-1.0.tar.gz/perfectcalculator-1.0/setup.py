from setuptools import setup, find_packages

setup(
        name="perfectcalculator", 
        version=1.0,
        author="narahari_nguyen",
        author_email="nguyenelizabeth48@gmail.com",
        packages=find_packages(),
        install_requires=[], 
)